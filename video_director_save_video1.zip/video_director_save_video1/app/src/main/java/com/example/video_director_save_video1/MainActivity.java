package com.example.video_director_save_video1;


/*

 * Copyright 2020 The omar_abou_hassan Open Source Project
 https://github.com/omaraldailam/video-director

 */
import androidx.appcompat.app.AppCompatActivity;

import android.animation.TimeAnimator;
import android.opengl.GLES20;
import android.os.Build;
import android.os.Bundle;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLExt;
import android.opengl.EGLSurface;
import android.opengl.GLES20;

import android.util.Log;
import android.view.Surface;
import android.widget.Button;

import java.io.IOException;
import java.nio.ByteBuffer;
public class MainActivity extends AppCompatActivity {
    private opengl_surface_view openglSurfaceView;
    private opengl_surface_view openglSurfaceView_save;
    SurfaceView surfaceView1;
    private static final String TAG = "Encode";
    private static final boolean VERBOSE = false;
    private TimeAnimator timeAnimator = new TimeAnimator();

    private static final String OUTPUT_DIR = "/sdcard/";

    // parameters for the encoder
    private static final String MIME_TYPE = "video/avc";

    private static final int FRAME_RATE = 15;               // 15fps
    private static final int IFRAME_INTERVAL = 10;          // 10 seconds between I-frames
    private static final int NUM_FRAMES = 30;
    // size of a frame, in pixels
    private int mWidth = 800;
    private int mHeight = 600;
    // bit rate, in bits per second
    private int mBitRate = 2000000;

    // encoder / muxer state
    private MediaCodec mEncoder;

    private MediaMuxer mMuxer;
    private int mTrackIndex;
    private boolean mMuxerStarted;

    // allocate one of these up front so we don't need to do it every time
    private MediaCodec.BufferInfo mBufferInfo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        surfaceView1=(SurfaceView)findViewById(R.id.surfaceView);
        surfaceView1.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                openglSurfaceView=new opengl_surface_view(holder.getSurface());


            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {

            }
        });
    }
    public void play(View view){
        final int[] xmov = {0};
        final int[] ymov = {0};
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            timeAnimator.setTimeListener(new TimeAnimator.TimeListener() {
                @Override
                public void onTimeUpdate(TimeAnimator animation, long totalTime, long deltaTime) {
                    if (xmov[0] >400){
                        xmov[0] =0;
                        ymov[0] =0;
                    }
                    xmov[0]++;
                    ymov[0]++;
                    openglSurfaceView.makeCurrent();
                    gldrw(xmov[0],ymov[0]);
                    openglSurfaceView.setPresentationTime(speedviw(xmov[0],1000000000));
                    openglSurfaceView.swapBuffers();
                    if (isrocd==1) {
                        openglSurfaceView_save.makeCurrent();
                        drainEncoder(false);
                        gldrw(xmov[0], ymov[0]);
                        openglSurfaceView_save.setPresentationTime(speedviw(xmov[0], 1000000000));
                        openglSurfaceView_save.swapBuffers();



                    }else if(isrocd==2){
                        drainEncoder(true);
                        releaseEncoder();
                        isrocd=0;
                        timeAnimator.pause();
                    }
                }
            });
            timeAnimator.start();
        }
    }
    public int isrocd =0;
    public void save_Rocid(View view){
        Button button=(Button)findViewById(R.id.button3);
        if(isrocd==0){

            prepareEncoder();
            isrocd=1;
            button.setText("isRic");
            // (Button)findViewById(R.id.button3).setText("");
        }
        else if(isrocd==1){
            isrocd=2; //stop save


            button.setText("isfinsh");
        }else if(isrocd==2){

            //isrocd=0;//new recod
            // button.setText("new_roced");
            //releaseEncoder();

        }


    }
    private void releaseEncoder() {
        if (VERBOSE) Log.d(TAG, "releasing encoder objects");
        if (mEncoder != null) {
            mEncoder.stop();
            mEncoder.release();
            mEncoder = null;
        }
        if (openglSurfaceView_save != null) {
            openglSurfaceView_save.release();
            openglSurfaceView_save = null;
        }
        if (mMuxer != null) {
            mMuxer.stop();
            mMuxer.release();
            mMuxer = null;
        }
    }


    private void prepareEncoder() {
        mBufferInfo = new MediaCodec.BufferInfo();

        MediaFormat format = MediaFormat.createVideoFormat(MIME_TYPE, mWidth, mHeight);


        format.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        format.setInteger(MediaFormat.KEY_BIT_RATE, mBitRate);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, FRAME_RATE);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, IFRAME_INTERVAL);
        if (VERBOSE) Log.d(TAG, "format: " + format);


        try {
            mEncoder = MediaCodec.createEncoderByType(MIME_TYPE);
        } catch (IOException e) {
            e.printStackTrace();
        }
        mEncoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        openglSurfaceView_save = new opengl_surface_view(mEncoder.createInputSurface());
        mEncoder.start();


        String outputPath = OUTPUT_DIR + "test." + mWidth + "x" + mHeight + ".mp4";
        Log.d(TAG, "output file is " + outputPath);


        try {
            mMuxer = new MediaMuxer(outputPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        } catch (IOException ioe) {
            throw new RuntimeException("MediaMuxer creation failed", ioe);
        }

        mTrackIndex = -1;
        mMuxerStarted = false;
    }

    private static long speedviw(int frameIndex,long speed) {
        // final long ONE_BILLION = 1000000000;
        final long ONE_BILLION = speed;
        return frameIndex * ONE_BILLION / FRAME_RATE;
    }

    private void drainEncoder(boolean endOfStream) {
        final int TIMEOUT_USEC = 10000;
        if (VERBOSE) Log.d(TAG, "drainEncoder(" + endOfStream + ")");

        if (endOfStream) {
            if (VERBOSE) Log.d(TAG, "sending EOS to encoder");
            mEncoder.signalEndOfInputStream();
        }

        ByteBuffer[] encoderOutputBuffers = mEncoder.getOutputBuffers();
        while (true) {
            int encoderStatus = mEncoder.dequeueOutputBuffer(mBufferInfo, TIMEOUT_USEC);
            if (encoderStatus == MediaCodec.INFO_TRY_AGAIN_LATER) {
                // no output available yet
                if (!endOfStream) {
                    break;      // out of while
                } else {
                    if (VERBOSE) Log.d(TAG, "no output available, spinning to await EOS");
                }
            } else if (encoderStatus == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED) {
                // not expected for an encoder
                encoderOutputBuffers = mEncoder.getOutputBuffers();
            } else if (encoderStatus == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                // should happen before receiving buffers, and should only happen once
                if (mMuxerStarted) {
                    throw new RuntimeException("format changed twice");
                }
                MediaFormat newFormat = mEncoder.getOutputFormat();
                Log.d(TAG, "encoder output format changed: " + newFormat);

                // now that we have the Magic Goodies, start the muxer
                mTrackIndex = mMuxer.addTrack(newFormat);
                mMuxer.start();
                mMuxerStarted = true;
            } else if (encoderStatus < 0) {
                Log.w(TAG, "unexpected result from encoder.dequeueOutputBuffer: " +
                        encoderStatus);
                // let's ignore it
            } else {
                ByteBuffer encodedData = encoderOutputBuffers[encoderStatus];
                if (encodedData == null) {
                    throw new RuntimeException("encoderOutputBuffer " + encoderStatus +
                            " was null");
                }

                if ((mBufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                    // The codec config data was pulled out and fed to the muxer when we got
                    // the INFO_OUTPUT_FORMAT_CHANGED status.  Ignore it.
                    if (VERBOSE) Log.d(TAG, "ignoring BUFFER_FLAG_CODEC_CONFIG");
                    mBufferInfo.size = 0;
                }

                if (mBufferInfo.size != 0) {
                    if (!mMuxerStarted) {
                        throw new RuntimeException("muxer hasn't started");
                    }

                    // adjust the ByteBuffer values to match BufferInfo (not needed?)
                    encodedData.position(mBufferInfo.offset);
                    encodedData.limit(mBufferInfo.offset + mBufferInfo.size);

                    mMuxer.writeSampleData(mTrackIndex, encodedData, mBufferInfo);
                    if (VERBOSE) Log.d(TAG, "sent " + mBufferInfo.size + " bytes to muxer");
                }

                mEncoder.releaseOutputBuffer(encoderStatus, false);

                if ((mBufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    if (!endOfStream) {
                        Log.w(TAG, "reached end of stream unexpectedly");
                    } else {
                        if (VERBOSE) Log.d(TAG, "end of stream reached");
                    }
                    break;      // out of while
                }
            }
        }
    }


    public void gldrw(int x,int y){
        GLES20.glViewport(0,0,800,600);
        GLES20.glClearColor( 1.0f,  1.0f, 0.0f , 1.0f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        GLES20.glEnable(GLES20.GL_SCISSOR_TEST);
        GLES20.glScissor(x, y, 800 / 4, 600 / 2);
        GLES20.glClearColor(20 / 255.0f, 255 / 255.0f, 40 / 255.0f, 1.0f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        GLES20.glDisable(GLES20.GL_SCISSOR_TEST);

        GLES20.glEnable(GLES20.GL_SCISSOR_TEST);
        GLES20.glScissor(200, 100, 800 / 4, 600 / 2);
        GLES20.glClearColor(20 / 255.0f, 255 / 255.0f, 255 / 255.0f, 1.0f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        GLES20.glDisable(GLES20.GL_SCISSOR_TEST);
    }
}

